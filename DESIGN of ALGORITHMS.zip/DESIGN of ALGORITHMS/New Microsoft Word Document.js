// SELECTIONSORT
function selectionSort(arr) {
  const a = arr.slice();
  for (let i = 0; i < a.length; i++) {
    let minIdx = i;
    for (let j = i + 1; j < a.length; j++) {
      if (a[j] < a[minIdx]) minIdx = j;
    }
    if (minIdx !== i) [a[i], a[minIdx]] = [a[minIdx], a[i]];
  }
  return a;
}

// INSERTIONSORT
function insertionSort(arr) {
  const a = arr.slice();
  for (let i = 1; i < a.length; i++) {
    const key = a[i];
    let j = i - 1;
    while (j >= 0 && a[j] > key) {
      a[j + 1] = a[j];
      j--;
    }
    a[j + 1] = key;
  }
  return a;
}

// BUBBLESORT
function bubbleSort(arr) {
  const a = arr.slice();
  for (let end = a.length - 1; end > 0; end--) {
    let swapped = false;
    for (let i = 0; i < end; i++) {
      if (a[i] > a[i + 1]) {
        [a[i], a[i + 1]] = [a[i + 1], a[i]];
        swapped = true;
      }
    }
    if (!swapped) break;
  }
  return a;
}

// SHAKERSORT (Cocktail sort)
function shakerSort(arr) {
  const a = arr.slice();
  let left = 0,
    right = a.length - 1;
  while (left < right) {
    let swapped = false;

    for (let i = left; i < right; i++) {
      if (a[i] > a[i + 1]) {
        [a[i], a[i + 1]] = [a[i + 1], a[i]];
        swapped = true;
      }
    }
    right--;

    for (let i = right; i > left; i--) {
      if (a[i - 1] > a[i]) {
        [a[i - 1], a[i]] = [a[i], a[i - 1]];
        swapped = true;
      }
    }
    left++;

    if (!swapped) break;
  }
  return a;
}

// SHELLSORT (gap halving)
function shellSort(arr) {
  const a = arr.slice();
  for (let gap = Math.floor(a.length / 2); gap > 0; gap = Math.floor(gap / 2)) {
    for (let i = gap; i < a.length; i++) {
      const temp = a[i];
      let j = i;
      while (j >= gap && a[j - gap] > temp) {
        a[j] = a[j - gap];
        j -= gap;
      }
      a[j] = temp;
    }
  }
  return a;
}

// COUNTINGSORT (integers; supports negatives via offset)
function countingSort(arr) {
  if (arr.length === 0) return [];
  let min = arr[0],
    max = arr[0];
  for (const x of arr) {
    if (x < min) min = x;
    if (x > max) max = x;
  }

  const offset = -min;
  const count = new Array(max - min + 1).fill(0);
  for (const x of arr) count[x + offset]++;

  const out = [];
  for (let i = 0; i < count.length; i++) {
    while (count[i]-- > 0) out.push(i - offset);
  }
  return out;
}

// RADIXSORT (LSD base-10; non-negative integers)
function radixSort(arr) {
  const a = arr.slice();
  if (a.length === 0) return [];
  if (a.some((x) => x < 0))
    throw new Error("radixSort expects non-negative integers.");

  let exp = 1;
  let max = Math.max(...a);

  while (Math.floor(max / exp) > 0) {
    const buckets = Array.from({ length: 10 }, () => []);
    for (const x of a) {
      const digit = Math.floor(x / exp) % 10;
      buckets[digit].push(x);
    }
    let k = 0;
    for (const b of buckets) for (const x of b) a[k++] = x;
    exp *= 10;
  }
  return a;
}

// QUICKSORT (in-place on a copy)
function quickSort(arr) {
  const a = arr.slice();

  function partition(lo, hi) {
    const pivot = a[hi];
    let i = lo;
    for (let j = lo; j < hi; j++) {
      if (a[j] <= pivot) {
        [a[i], a[j]] = [a[j], a[i]];
        i++;
      }
    }
    [a[i], a[hi]] = [a[hi], a[i]];
    return i;
  }

  function qs(lo, hi) {
    if (lo >= hi) return;
    const p = partition(lo, hi);
    qs(lo, p - 1);
    qs(p + 1, hi);
  }

  qs(0, a.length - 1);
  return a;
}

// MERGESORT
function mergeSort(arr) {
  if (arr.length <= 1) return arr.slice();

  const mid = Math.floor(arr.length / 2);
  const left = mergeSort(arr.slice(0, mid));
  const right = mergeSort(arr.slice(mid));

  const out = [];
  let i = 0,
    j = 0;
  while (i < left.length && j < right.length) {
    out.push(left[i] <= right[j] ? left[i++] : right[j++]);
  }
  while (i < left.length) out.push(left[i++]);
  while (j < right.length) out.push(right[j++]);
  return out;
}

// Knuth–Morris–Pratt (KMP): returns all match start indices
function kmpSearch(text, pattern) {
  if (pattern.length === 0)
    return Array.from({ length: text.length + 1 }, (_, i) => i);

  // build LPS (longest prefix suffix)
  const lps = new Array(pattern.length).fill(0);
  for (let i = 1, len = 0; i < pattern.length; ) {
    if (pattern[i] === pattern[len]) lps[i++] = ++len;
    else if (len) len = lps[len - 1];
    else lps[i++] = 0;
  }

  const res = [];
  for (let i = 0, j = 0; i < text.length; ) {
    if (text[i] === pattern[j]) {
      i++;
      j++;
    }
    if (j === pattern.length) {
      res.push(i - j);
      j = lps[j - 1];
    } else if (i < text.length && text[i] !== pattern[j]) {
      j ? (j = lps[j - 1]) : i++;
    }
  }
  return res;
}

// Rabin–Karp: returns all match start indices (rolling hash)
function rabinKarpSearch(text, pattern) {
  const n = text.length,
    m = pattern.length;
  if (m === 0) return Array.from({ length: n + 1 }, (_, i) => i);
  if (m > n) return [];

  const base = 256;
  const mod = 1_000_000_007;

  let pHash = 0,
    tHash = 0,
    pow = 1;
  for (let i = 0; i < m - 1; i++) pow = (pow * base) % mod;

  for (let i = 0; i < m; i++) {
    pHash = (pHash * base + pattern.charCodeAt(i)) % mod;
    tHash = (tHash * base + text.charCodeAt(i)) % mod;
  }

  const res = [];
  for (let i = 0; i <= n - m; i++) {
    if (pHash === tHash) {
      // verify to avoid false positives
      let ok = true;
      for (let j = 0; j < m; j++) {
        if (text[i + j] !== pattern[j]) {
          ok = false;
          break;
        }
      }
      if (ok) res.push(i);
    }
    if (i < n - m) {
      const left = text.charCodeAt(i);
      const right = text.charCodeAt(i + m);
      tHash = (tHash - ((left * pow) % mod) + mod) % mod;
      tHash = (tHash * base + right) % mod;
    }
  }
  return res;
}

// Boyer–Moore (bad-character rule only): returns all match start indices
function boyerMooreSearch(text, pattern) {
  const n = text.length,
    m = pattern.length;
  if (m === 0) return Array.from({ length: n + 1 }, (_, i) => i);

  // last occurrence table
  const last = new Map();
  for (let i = 0; i < m; i++) last.set(pattern[i], i);

  const res = [];
  let s = 0; // shift
  while (s <= n - m) {
    let j = m - 1;
    while (j >= 0 && pattern[j] === text[s + j]) j--;
    if (j < 0) {
      res.push(s);
      s += s + m < n ? m - (last.get(text[s + m]) ?? -1) : 1;
    } else {
      const lo = last.get(text[s + j]) ?? -1;
      s += Math.max(1, j - lo);
    }
  }
  return res;
}

// Memoization template (top-down)
function memoize(fn) {
  const memo = new Map();
  return function (...args) {
    const key = JSON.stringify(args);
    if (memo.has(key)) return memo.get(key);
    const val = fn.apply(this, args);
    memo.set(key, val);
    return val;
  };
}

// Example DP: 0/1 Knapsack (tabulation)
// weights[i], values[i], capacity W -> max value
function knapsack01(weights, values, W) {
  const n = weights.length;
  const dp = Array.from({ length: n + 1 }, () => new Array(W + 1).fill(0));

  for (let i = 1; i <= n; i++) {
    const wt = weights[i - 1],
      val = values[i - 1];
    for (let w = 0; w <= W; w++) {
      dp[i][w] = dp[i - 1][w];
      if (wt <= w) dp[i][w] = Math.max(dp[i][w], dp[i - 1][w - wt] + val);
    }
  }
  return dp[n][W];
}

// ----- Utilities -----
class UnionFind {
  constructor(n) {
    this.parent = Array.from({ length: n }, (_, i) => i);
    this.rank = new Array(n).fill(0);
  }
  find(x) {
    while (this.parent[x] !== x) {
      this.parent[x] = this.parent[this.parent[x]];
      x = this.parent[x];
    }
    return x;
  }
  union(a, b) {
    a = this.find(a);
    b = this.find(b);
    if (a === b) return false;
    if (this.rank[a] < this.rank[b]) [a, b] = [b, a];
    this.parent[b] = a;
    if (this.rank[a] === this.rank[b]) this.rank[a]++;
    return true;
  }
}

class MinHeap {
  constructor() {
    this.h = [];
  }
  size() {
    return this.h.length;
  }
  push(item) {
    this.h.push(item);
    this._up(this.h.length - 1);
  }
  pop() {
    if (!this.h.length) return null;
    const top = this.h[0];
    const last = this.h.pop();
    if (this.h.length) {
      this.h[0] = last;
      this._down(0);
    }
    return top;
  }
  _up(i) {
    while (i > 0) {
      const p = (i - 1) >> 1;
      if (this.h[p][0] <= this.h[i][0]) break;
      [this.h[p], this.h[i]] = [this.h[i], this.h[p]];
      i = p;
    }
  }
  _down(i) {
    const n = this.h.length;
    while (true) {
      let m = i,
        l = i * 2 + 1,
        r = l + 1;
      if (l < n && this.h[l][0] < this.h[m][0]) m = l;
      if (r < n && this.h[r][0] < this.h[m][0]) m = r;
      if (m === i) break;
      [this.h[m], this.h[i]] = [this.h[i], this.h[m]];
      i = m;
    }
  }
}

// Graph formats used below:
// - Weighted adjacency list: adj[u] = [{to, w}, ...]
// - Edge list (weighted): edges = [{u, v, w}, ...] (undirected unless stated)
// - Capacity matrix: capacity[u][v] = number (directed)

// ----- Ford–Fulkerson (Edmonds–Karp BFS) -----
function fordFulkersonEdmondsKarp(capacity, s, t) {
  const n = capacity.length;
  const flow = Array.from({ length: n }, () => new Array(n).fill(0));
  let maxFlow = 0;

  while (true) {
    const parent = new Array(n).fill(-1);
    parent[s] = s;
    const q = [s];

    for (let qi = 0; qi < q.length; qi++) {
      const u = q[qi];
      for (let v = 0; v < n; v++) {
        const residual = capacity[u][v] - flow[u][v];
        if (parent[v] === -1 && residual > 0) {
          parent[v] = u;
          q.push(v);
        }
      }
    }
    if (parent[t] === -1) break;

    let aug = Infinity;
    for (let v = t; v !== s; v = parent[v]) {
      const u = parent[v];
      aug = Math.min(aug, capacity[u][v] - flow[u][v]);
    }
    for (let v = t; v !== s; v = parent[v]) {
      const u = parent[v];
      flow[u][v] += aug;
      flow[v][u] -= aug;
    }
    maxFlow += aug;
  }

  return maxFlow;
}

// ----- Kruskal (MST) -----
function kruskalMST(n, edges) {
  const uf = new UnionFind(n);
  const sorted = edges.slice().sort((a, b) => a.w - b.w);
  const mst = [];
  let total = 0;

  for (const e of sorted) {
    if (uf.union(e.u, e.v)) {
      mst.push(e);
      total += e.w;
      if (mst.length === n - 1) break;
    }
  }
  return { totalWeight: total, edges: mst };
}

// ----- Prim (MST) using heap -----
function primMST(n, adj, start = 0) {
  const inMST = new Array(n).fill(false);
  const heap = new MinHeap(); // [w, u, parent]
  heap.push([0, start, -1]);

  const mst = [];
  let total = 0;

  while (heap.size() && mst.length < n - 1) {
    const [w, u, parent] = heap.pop();
    if (inMST[u]) continue;
    inMST[u] = true;
    if (parent !== -1) {
      mst.push({ u: parent, v: u, w });
      total += w;
    }
    for (const { to, w: w2 } of adj[u] || []) {
      if (!inMST[to]) heap.push([w2, to, u]);
    }
  }
  return { totalWeight: total, edges: mst };
}

// ----- Borůvka (MST) -----
function boruvkaMST(n, edges) {
  const uf = new UnionFind(n);
  let components = n;
  const mst = [];
  let total = 0;

  while (components > 1) {
    const cheapest = new Array(n).fill(null);

    for (const e of edges) {
      const a = uf.find(e.u),
        b = uf.find(e.v);
      if (a === b) continue;
      if (!cheapest[a] || e.w < cheapest[a].w) cheapest[a] = e;
      if (!cheapest[b] || e.w < cheapest[b].w) cheapest[b] = e;
    }

    let added = 0;
    for (let i = 0; i < n; i++) {
      const e = cheapest[i];
      if (!e) continue;
      if (uf.union(e.u, e.v)) {
        mst.push(e);
        total += e.w;
        components--;
        added++;
      }
    }

    if (added === 0) break; // disconnected graph
  }

  return { totalWeight: total, edges: mst };
}

// ----- Dijkstra (non-negative weights) -----
function dijkstra(n, adj, source) {
  const dist = new Array(n).fill(Infinity);
  dist[source] = 0;

  const heap = new MinHeap(); // [dist, node]
  heap.push([0, source]);

  while (heap.size()) {
    const [d, u] = heap.pop();
    if (d !== dist[u]) continue;
    for (const { to, w } of adj[u] || []) {
      const nd = d + w;
      if (nd < dist[to]) {
        dist[to] = nd;
        heap.push([nd, to]);
      }
    }
  }
  return dist;
}

// ----- Bellman-Ford (can handle negative weights; detects negative cycles) -----
// edgesDirected = [{u, v, w}, ...]
function bellmanFord(n, edgesDirected, source) {
  const dist = new Array(n).fill(Infinity);
  dist[source] = 0;

  for (let i = 0; i < n - 1; i++) {
    let changed = false;
    for (const e of edgesDirected) {
      if (dist[e.u] !== Infinity && dist[e.u] + e.w < dist[e.v]) {
        dist[e.v] = dist[e.u] + e.w;
        changed = true;
      }
    }
    if (!changed) break;
  }

  // negative cycle check
  let hasNegativeCycle = false;
  for (const e of edgesDirected) {
    if (dist[e.u] !== Infinity && dist[e.u] + e.w < dist[e.v]) {
      hasNegativeCycle = true;
      break;
    }
  }
  return { dist, hasNegativeCycle };
}

// ----- BFS (unweighted) -----
// adjUnweighted[u] = [v1, v2, ...]
function bfs(adjUnweighted, start) {
  const n = adjUnweighted.length;
  const visited = new Array(n).fill(false);
  const order = [];
  const q = [start];
  visited[start] = true;

  for (let qi = 0; qi < q.length; qi++) {
    const u = q[qi];
    order.push(u);
    for (const v of adjUnweighted[u] || []) {
      if (!visited[v]) {
        visited[v] = true;
        q.push(v);
      }
    }
  }
  return order;
}

// ----- DFS (unweighted) -----
function dfsIterative(adjUnweighted, start) {
  const n = adjUnweighted.length;
  const visited = new Array(n).fill(false);
  const order = [];
  const stack = [start];

  while (stack.length) {
    const u = stack.pop();
    if (visited[u]) continue;
    visited[u] = true;
    order.push(u);
    const neigh = adjUnweighted[u] || [];
    for (let i = neigh.length - 1; i >= 0; i--) {
      const v = neigh[i];
      if (!visited[v]) stack.push(v);
    }
  }
  return order;
}
